HOW TO UPDATE :

Upload the whole project files to your project path and replace all and import the update.sql to your database
Changes We made :

[ADD] KYC Verification
[ADD] Strong Reporting
[ADD] Controllable language system
[ADD] Maintenance Mode
[PATCH] Admin UI/UX
[PATCH] Bootstrap 5
[PATCH] Laravel 9
[PATCH] PHP 8.1

NOTE: Please make a backup to your project and database to avoid un-wanted issues